= Credit =
- TrueReview is based off Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc.
- Hybrid folder is based off Hybrid Core part http://themehybrid.com/hybrid-core, (C) 2010-2015 Justin Tadlock.
- Customizer library by Devin Price, https://github.com/devinsays/customizer-library
- TGMPA Library, https://github.com/TGMPA/TGM-Plugin-Activation

= Useful Links =
- Documentation: http://docs.theme-junkie.com/truereview
- Support      : http://www.theme-junkie.com/support
- Twitter      : https://twitter.com/theme_junkie
